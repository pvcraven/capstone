import java.io.BufferedReader;
import java.io.FileReader;
import java.text.BreakIterator;
import java.util.*;

public class Test05 {
    public static void main(String args[]) {
        try {
            // --- Read in the dictionary ---
            System.out.println("Reading in the dictionary");
            long startTime = System.nanoTime();
            BufferedReader br = new BufferedReader(new FileReader("dictionary.txt"));

            // ENABLE ONE OF THE LINES BELOW:

            //HashSet<String> dictionary = new HashSet<String>();
            //LinkedList<String> dictionary = new LinkedList<String>();
            //TreeSet<String> dictionary = new TreeSet<String>();
            //Stack<String> dictionary = new Stack<String>();
            //ArrayList<String> dictionary = new ArrayList<String>();

            String word = br.readLine();
            while(word != null) {
                dictionary.add(word.toUpperCase());
                word = br.readLine();
            }

            br.close();
            long endTime = System.nanoTime();
            double duration = (endTime - startTime) / 1000000000.;
            System.out.println(String.format("Done reading the dictionary with %,d words in %f seconds.", dictionary.size(), duration));

            // --- Read in the story ---
            System.out.println("Reading in the story");
            br = new BufferedReader(new FileReader("dracula.txt"));
            String line = br.readLine();
            LinkedList<String> story = new LinkedList<String>();
            while(line != null) {
                story.add(line.toUpperCase());
                line = br.readLine();
            }
            br.close();
            System.out.println(String.format("Done reading the story with %,d lines.", story.size()));

            // --- Iterate Story ---
            startTime = System.nanoTime();

            BreakIterator wordIterator = BreakIterator.getWordInstance();
            int lineNumber = 0;
            for (String myline : story) {
                lineNumber += 1;

                wordIterator.setText(myline.toUpperCase());
                int boundary = wordIterator.first();
                int start = wordIterator.first();
                int end = wordIterator.next();

                while (end != -1 && boundary != BreakIterator.DONE) {

                    word = myline.substring(start, end);
                    if (Character.isLetter(word.charAt(0))) {
                        if(!dictionary.contains(word)) {
                            System.out.println(String.format("Unknown word: `%s` on line %d.", word, lineNumber));
                        }
                    }
                    start = end;
                    end = wordIterator.next();
                }
            }
            endTime = System.nanoTime();
            duration = (endTime - startTime) / 1000000000.;
            System.out.println(String.format("Done spellchecking in %f seconds.", duration));
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
}
